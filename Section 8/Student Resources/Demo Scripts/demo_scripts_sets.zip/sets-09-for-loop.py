# Sets - A set is an unordered collection of items.

# Creating Sets
set_nums = {1, 2, 3, 4, 5}
set_names = {'John', 'Kim', 'Kelly', 'Dora'}

# Run multiple times & check the order
for name in set_names:
    print("Name : ", name)