# Sets - A set is an unordered collection of items.

# Sample Set
set_names = {'John', 'Kim', 'Kelly', 'Dora'}

print('Kim' in set_names)
print('Kim2' not in set_names)
