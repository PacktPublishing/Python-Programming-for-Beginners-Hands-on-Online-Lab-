# Sets - A set is an unordered collection of unique and immutable objects.
# Sets are mutable because you add object to it.
# add, update

# Creating Sets
set_names = {'John', 'Kim', 'Kelly', 'Dora'}

set_names.add("Peter")

set_names.update(["A", "B", "C"])

set_names.update({"AA", "BB", "CC"})

print(set_names)