# My first module


def calc_add(num1, num2):
    return num1 + num2


def calc_diff(num1, num2):
    return num2 - num2

a = 10
b = 20
print("The sum of {} and {} is {}.".format(a, b, calc_add(a, b)))