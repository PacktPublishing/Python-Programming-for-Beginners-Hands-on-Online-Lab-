# My first module


def calc_add(num1, num2):
    print("Adding....")
    return num1 + num2


def calc_diff(num1, num2):
    print("Diff....")
    return num1 - num2


if __name__ == '__main__':
    a = 10
    b = 20
    print("The sum of {} and {} is {}.".format(a, b, calc_add(a, b)))