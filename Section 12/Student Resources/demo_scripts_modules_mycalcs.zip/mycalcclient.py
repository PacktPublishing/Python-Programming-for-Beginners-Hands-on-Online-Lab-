import mycalc

n1 = 50
n2 = 30

result = mycalc.calc_diff(n1, n2)

print(result)