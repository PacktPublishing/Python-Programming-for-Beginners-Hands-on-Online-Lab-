import mycalcv2

n1 = 50
n2 = 30

result = mycalcv2.calc_diff(n1, n2)

print("The diff of {} and {} is {}.".format(n1, n2, result))