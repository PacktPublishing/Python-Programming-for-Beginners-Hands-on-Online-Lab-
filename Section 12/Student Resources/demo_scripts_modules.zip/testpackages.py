import mypkg.subpkg2.mymod21 as mod21
import mypkg.subpkg2.mymod22 as mod22


print("----")
mod21.hello()
print("----")
mod22.hello()

