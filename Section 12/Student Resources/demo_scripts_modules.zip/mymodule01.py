import math
import os

number = 30

print(math.sqrt(number))
print(math.pi)

print(os.name)
print(os.getlogin())