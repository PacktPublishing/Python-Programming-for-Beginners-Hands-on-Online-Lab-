
print(__name__ + " Initialized")