def internal_transfers(from_acct_no, from_acct_type, to_acct_no, to_acct_type):
    """
    This function handles internal transfers.

    """
    return None


def external_transfers(from_acct_no, from_acct_type, ext_acct_no, ext_acct_type, ext_bank_aba):
    """
    This function handles external transfers.

    """
    return None


# __doc__
print("Using __doc__")
print(internal_transfers.__doc__)
print(external_transfers.__doc__)

# help
print("Using help")
print(help(internal_transfers))
print(help(external_transfers))
