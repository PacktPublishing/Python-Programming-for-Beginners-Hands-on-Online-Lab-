def hello():
    print("Helmymod31.pylo from {}".format(__name__))