def hello():
    print("Hello from {}".format(__name__))