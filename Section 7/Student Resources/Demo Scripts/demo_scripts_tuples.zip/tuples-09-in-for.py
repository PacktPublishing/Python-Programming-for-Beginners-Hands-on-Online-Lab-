# Tuples
# A tuple is an immutable sequence of Python objects.

# Create & print
tuple_1 = ('apple', 'mango', 'banana', 'grapes')
print(tuple_1)

# Membership Operator - in
print("apple1" in tuple_1)

# Iterate
for x in tuple_1:
    print('Fruit : ', x)