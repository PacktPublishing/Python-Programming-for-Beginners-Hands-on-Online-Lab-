# Tuples
# A tuple is an immutable sequence of Python objects.

# Tuples
tuple_1 = ('apple', 'mango', 'apple', 'banana', 'grapes', 'apple', 'mango', 'banana')
tuple_2 = (1, 3, 5, 7, 8, 9, 1, 2, 4, 7, 8, 9, 0, 2, 3, 4, 5, 6, 7, 4, 5, 8, 9, 1)

# count
print("Count :")
print(tuple_2.count(2))

# Get Index (First found)
print('Index : ', tuple_2.index(5))
