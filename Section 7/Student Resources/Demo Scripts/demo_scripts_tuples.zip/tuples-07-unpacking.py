# Tuples
# A tuple is an immutable sequence of Python objects.
# unpacking

tuple_1 = ('apple', 'mango', 'banana', 'grapes')

b, a, c, d = tuple_1

print(a, b, c, d)