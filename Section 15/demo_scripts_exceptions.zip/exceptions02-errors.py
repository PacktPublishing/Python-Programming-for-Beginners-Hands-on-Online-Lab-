# Error: List

animals = ['dog', 'cat', 'hen', 'fox', 'elephant', 'snake', 'pig']

print('Second : ', animals[1])
print('Second : ', animals[7])

