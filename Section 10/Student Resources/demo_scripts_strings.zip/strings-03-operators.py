# Strings
# A string is a sequence of characters.
# +, +=, *

# Strings
string_01 = "Python"
string_02 = "Programming"
string_03 = 'is'
string_04 = 'FUN'

# Using +
print(string_01 + string_02 + string_03 + string_04)
print(string_01 + " " + string_02 + " " + string_03 + " " + string_04 + "!!")

# Using +=
message = "This is a sample message."
message += " "
message += "Please"
message += " "
message += "ack."
print(message)

# Using *
print(string_01 * 5)
print((string_01 + " ") * 5)
