# Strings
# A string is a sequence of characters

# Create
string_01 = "Python Programming is FUN!!"

print('First Character : ', string_01[0])
print('Second Character : ', string_01[1])

print('Last Character : ', string_01[-1])

print('8th to 18th Characters: ', string_01[7:18])

print('8th to 3rd from last : ', string_01[7:-2])

# Error: string index out of range
#print('8th to 3rd from last : ', string_01[30])