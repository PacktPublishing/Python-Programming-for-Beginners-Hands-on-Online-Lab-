# Strings
# A string is a sequence of characters.

# Create
string_01 = "Python Programming!"

print("P" in string_01)

x = input("Enter a character : ")

if x in string_01:
    print("Found the character!")
else:
    print("Character not found!")