# Strings
# split -> joins items of a sequence into a string

employee_Information = ['John Papa', 'Network', '02/24/1975', '$60K US']
print(type(employee_Information))


message = "It is urgent!!"

print(message)
print("7".join(message))