# Strings
# A string is a sequence of characters.

# Create
string_01 = "Python Programming!"

for char in "Hello":
    print(char)