# Strings
# A string is a sequence of characters.

# Create
string_01 = "Python Programming!"
string_02 = "Python"

print(len(string_02))