

my_file = "sample.txt"

# Open
file_handler = open(my_file, "w")

# Write
file_handler.write("3: From Python Code!")

# Close
file_handler.close()