# Functions - Return Values


def add(num1, num2):
    print("Adding.....")
    add_total = num1 + num2
    return add_total


total = add(10, 5)
print(str(total))