# Functions - Basics


def print_message():
    print(" Alert! ".center(30, "*"))
    print(" Hello World!")
    print(" How are you?!")
    print("-----")

print_message()
print_message()
print_message()
