# Functions - Parameters


def print_message_format1(message):
    print(message)


def print_message_format2(message, number):
    print(str(number) + " : " + message)


message1 = "Hello World!"
print_message_format1(message1)
print_message_format2(message1, 100)
message2 = "This is great!"
print_message_format2(message2, 200)


