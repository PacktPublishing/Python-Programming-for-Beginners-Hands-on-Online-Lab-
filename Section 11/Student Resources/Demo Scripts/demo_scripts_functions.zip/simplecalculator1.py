# Simple Calculator
# Ver1

num1 = 10
num2 = 20

sum = num1 + num2
diff = num1 - num2
prod = num1 * num2
div = num1 / num2
reminder = num1 % num2
quotient = num1 // num2

print("The sum of {} and {} : {}".format(num1, num2, sum))
print("The diff of {} and {} : {}".format(num1, num2, diff))
print("The prod of {} and {} : {}".format(num1, num2, prod))
print("The div of {} and {} : {}".format(num1, num2, div))
print("The reminder of {} and {} : {}".format(num1, num2, reminder))
print("The quotient of {} and {} : {}".format(num1, num2, quotient))