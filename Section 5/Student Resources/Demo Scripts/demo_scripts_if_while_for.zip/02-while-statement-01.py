# while statement basics
x = 0

while x <= 10:
    print('I am inside the while loop : ' + str(x))
    #x = x + 1
    x += 1
