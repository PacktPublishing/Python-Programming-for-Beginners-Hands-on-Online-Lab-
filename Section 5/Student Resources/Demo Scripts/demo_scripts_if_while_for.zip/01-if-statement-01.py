# Simple if and if..else statements

# Variables
raining = True
score = 50

# if Statement
if raining:
    print("Yes! It is raining")
    print("Yes! It is raining")
    print("Yes! It is raining")

# if..else Statement
if score >= 100:
    print('The score is greater than or equal to 100!')
    print('The score is greater than or equal to 100!')
    print('The score is greater than or equal to 100!')
else:
    print("The score is less than 100!")
    print("The score is less than 100!")

