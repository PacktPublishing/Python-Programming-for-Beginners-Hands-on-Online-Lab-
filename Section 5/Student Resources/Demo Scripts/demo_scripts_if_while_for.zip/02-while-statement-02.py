# while statement basics
x = 0

while x <= 12:
    print('I am inside the while loop : ' + str(x))
    if x == 5:
        print("Hey! Found 5!")
    x += 1