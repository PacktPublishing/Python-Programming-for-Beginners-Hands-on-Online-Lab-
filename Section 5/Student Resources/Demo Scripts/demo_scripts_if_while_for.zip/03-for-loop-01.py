# Simple for loop

for x in 1, 2, 3, 4, 5, "Hello":
    print('The value of x is ' + str(x))