# Lists
# A list is a mutable sequence of Python objects.
# Nested Lists

numbers = [1, 2, 3, 4, 5]

list_nested = [[1, 2, 3], ['a', 'b', 'c'], ['A', 'B', 'C']]

print(list_nested)
print(list_nested[0])
print(list_nested[0][0])
print(list_nested[2][0])