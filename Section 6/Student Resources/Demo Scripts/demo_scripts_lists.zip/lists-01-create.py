# Lists
# A list is a mutable sequence of Python objects

# Create
numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9]
names = ['John', 'Kim', 'Kelly', 'Dora']
animals = ['dog', 'cat', 'hen', 'fox', 'elephant']
groceries = ['onions', 'spinach', 'tomatoes', 'cilantro', 'milk']
my_list1 = [1, 2.34, 'John']
my_empty_list = []

print(names)

print(type(numbers))


