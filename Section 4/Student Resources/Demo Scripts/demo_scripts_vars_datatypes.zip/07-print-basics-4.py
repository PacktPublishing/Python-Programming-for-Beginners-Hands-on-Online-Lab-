# format basics
Name = "John"
City = "Boston"
Salary = "$100k"

print(Name + " lives in " + City + " and his salary is " + Salary)
print("----")
print("{} lives in {} and his salary is {}.".format(Name, City, Salary))