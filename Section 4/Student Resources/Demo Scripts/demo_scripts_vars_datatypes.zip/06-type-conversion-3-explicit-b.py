# Type Conversion - Explicit
# A.K.A Type Casting,
# One Data Type --> To Another Data Type

var_num1 = input("Enter number1 : ")
var_num2 = input("Enter number2 : ")

var_sum = float(var_num1) + float(var_num2)

print("var_num1 Data Type : ", type(var_num1))
print("var_num2 Data Type : ", type(var_num2))

print("Value of var_sum : ", var_sum)
print("var_sum Data Type : ", type(var_sum))
