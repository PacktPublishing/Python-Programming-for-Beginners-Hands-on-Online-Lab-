# Using the print function

print("London", "Paris", "New York")

# Using separator
print("London", "Paris", "New York", sep="|")

# using end
print("London", "Paris", "New York", sep=":", end="!!!")

print("\n")
# Using multiplier
print("a" * 10)
print("Hello" * 3)

# Using center
message = "Start Immediately!"
print(message)
print(message.center(30, "#"))
