# Type Conversion - Implicit
# Implicit Type Conversion is done by the Python interpreter

var_integer = 24
var_float = 2.6

var_sum = var_float + var_integer

print("var_integer Data Type : ", type(var_integer))
print("var_float Data Type : ", type(var_float))

print("The value of var_sum :", var_sum)
print("var_sum Data Type : ", type(var_sum))
