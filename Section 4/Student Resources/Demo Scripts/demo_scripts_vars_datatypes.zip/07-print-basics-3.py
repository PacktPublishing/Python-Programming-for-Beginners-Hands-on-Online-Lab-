# string vs int

a = 10
b = "ten"

print(a)
print(b)

print(a + b)