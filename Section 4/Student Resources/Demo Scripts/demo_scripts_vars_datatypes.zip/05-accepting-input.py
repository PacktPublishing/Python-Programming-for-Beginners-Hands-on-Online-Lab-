# Prompting user for input

# Prompt the user to enter name and read it into a variable
name = input('Enter your name : ')

# Display a message that includes the name entered by the user
print('Hello ' + name + '!' + ' ' + 'How are you today?')
