# Using the print function

# Simple usage
print("London")
print(100)
print(20.20)

# print with Variables
first_name = "John"
last_name = "Papa"
print(first_name, last_name, 1, 2, "Hello")

# Using +
print(first_name + last_name)
print(first_name + ", " +last_name)

# Inserting new line character & tab
print("Apples")
print("Banana")
print("Mangoes")
print("-----")
print("Apples \nBanana \nMangoes")
print("-----")
print("Apples \tBanana \tMangoes")
