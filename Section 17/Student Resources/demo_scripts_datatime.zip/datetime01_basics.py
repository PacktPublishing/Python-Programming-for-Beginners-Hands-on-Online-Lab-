# Working with dates
# Module: datatime

from datetime import date, datetime

date_today = date.today()
datetime_now = datetime.now()

print(date_today)
print(datetime_now)